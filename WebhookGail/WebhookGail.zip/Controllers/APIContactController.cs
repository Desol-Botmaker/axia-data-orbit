﻿using Microsoft.AspNetCore.Mvc;
using System.Text.Json;
using System.Text;
using WebhookGail.Data;
using WebhookGail.Models;
using WebhookGail.Middleware;

namespace WebhookGail.Controllers
{
    [ApiController]
    [Route("axia/contacts")]
    [ServiceFilter(typeof(TokenValidationMiddleware))]
    public class APIContactController : Controller
    {
        private readonly ILogger<APIContactController> _logger;
        private readonly HttpClient _httpClient;
        private readonly WebhookGailContext _dbContext;
        private readonly IConfiguration _configuration;
        private readonly string? _apiKey;
        private readonly string? _endpoint;
        public APIContactController(ILogger<APIContactController> logger, HttpClient httpClient, WebhookGailContext dbcontext, IConfiguration configuration)
        {

            _logger = logger;
            _httpClient = httpClient;
            _dbContext = dbcontext;
            _configuration = configuration;
            _apiKey = configuration["GailAPI:ApiKey"];
            _endpoint = configuration["GailAPI:Endpoint"];
        }

        private void AddCommonHeaders(HttpRequestMessage request)
        {
            request.Headers.Add("Authorization", "Bearer YOUR_ACCESS_TOKEN");
            request.Headers.Add("X-Org-ID", "3fa85f64-5717-4562-b3fc-2c963f66afa6");
        }

        [HttpGet]
        public async Task<IActionResult> GetContactsAsync()
        {
            var request = new HttpRequestMessage(HttpMethod.Get, $"{_endpoint}/v1/contacts");
            AddCommonHeaders(request);

            var response = await _httpClient.SendAsync(request);

            if (response.IsSuccessStatusCode)
            {
                var responseContent = await response.Content.ReadAsStringAsync();
                return Ok(responseContent);
            }
            else
            {
                var errorContent = await response.Content.ReadAsStringAsync();
                return BadRequest(new { status = response.StatusCode, error = errorContent });
            }
        }

        [HttpGet("{id}")]
        public async Task<IActionResult> GetContactAsync([FromRoute] string id)
        {
            var request = new HttpRequestMessage(HttpMethod.Get, $"{_endpoint}/v1/contacts/{id}");
            AddCommonHeaders(request);

            var response = await _httpClient.SendAsync(request);

            if (response.IsSuccessStatusCode)
            {
                var responseContent = await response.Content.ReadAsStringAsync();
                return Ok(responseContent);
            }
            else
            {
                var errorContent = await response.Content.ReadAsStringAsync();
                return BadRequest(new { status = response.StatusCode, error = errorContent });
            }
        }

        [HttpPost]
        public async Task<IActionResult> PostContactAsync([FromBody] Contact contact)
        {
            try
            {
                var request = new HttpRequestMessage(HttpMethod.Post, $"{_endpoint}/v1/contacts");
                AddCommonHeaders(request);

                string jsonContent = JsonSerializer.Serialize(contact);
                request.Content = new StringContent(jsonContent, Encoding.UTF8, "application/json");

                var response = await _httpClient.SendAsync(request);

                if (response.IsSuccessStatusCode)
                {
                    var responseContent = await response.Content.ReadAsStringAsync();
                    return Created("", responseContent);
                }
                else
                {
                    var errorContent = await response.Content.ReadAsStringAsync();
                    return BadRequest(new { status = response.StatusCode, error = errorContent });
                }
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Internal server error: {ex.Message}");
            }
        }

        [HttpPut("{id}")]
        public async Task<IActionResult> UpdateContactAsync([FromRoute] string id, [FromBody] Contact contact)
        {
            try
            {
                var request = new HttpRequestMessage(HttpMethod.Put, $"{_endpoint}/v1/contacts/{id}");
                AddCommonHeaders(request);

                string jsonContent = JsonSerializer.Serialize(contact);
                request.Content = new StringContent(jsonContent, Encoding.UTF8, "application/json");

                var response = await _httpClient.SendAsync(request);

                if (response.IsSuccessStatusCode)
                {
                    var responseContent = await response.Content.ReadAsStringAsync();
                    return Ok(responseContent);
                }
                else
                {
                    var errorContent = await response.Content.ReadAsStringAsync();
                    return BadRequest(new { status = response.StatusCode, error = errorContent });
                }
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Internal server error: {ex.Message}");
            }
        }

        [HttpPost("bulk_add")]
        public async Task<IActionResult> BulkAddContactsAsync([FromBody] List<Contact> contacts)
        {
            try
            {
                var request = new HttpRequestMessage(HttpMethod.Post, $"{_endpoint}/v1/contacts/bulk_add");
                AddCommonHeaders(request);

                string jsonContent = JsonSerializer.Serialize(contacts);
                request.Content = new StringContent(jsonContent, Encoding.UTF8, "application/json");

                var response = await _httpClient.SendAsync(request);

                if (response.IsSuccessStatusCode)
                {
                    var responseContent = await response.Content.ReadAsStringAsync();
                    return StatusCode(207, responseContent);
                }
                else
                {
                    var errorContent = await response.Content.ReadAsStringAsync();
                    return BadRequest(new { status = response.StatusCode, error = errorContent });
                }
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Internal server error: {ex.Message}");
            }
        }

        [HttpPost("{id}/archive")]
        public async Task<IActionResult> ArchiveContactAsync([FromRoute] string id)
        {
            try
            {
                var request = new HttpRequestMessage(HttpMethod.Post, $"{_endpoint}/v1/contacts/{id}/archive");
                AddCommonHeaders(request);

                var response = await _httpClient.SendAsync(request);

                if (response.IsSuccessStatusCode)
                {
                    var responseContent = await response.Content.ReadAsStringAsync();
                    return Ok(responseContent);
                }
                else
                {
                    var errorContent = await response.Content.ReadAsStringAsync();
                    return BadRequest(new { status = response.StatusCode, error = errorContent });
                }
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Internal server error: {ex.Message}");
            }
        }

        [HttpGet("variable_fields")]
        public async Task<IActionResult> GetVariableFieldsAsync()
        {
            var request = new HttpRequestMessage(HttpMethod.Get, $"{_endpoint}/v1/contacts/variable_fields");
            AddCommonHeaders(request);

            var response = await _httpClient.SendAsync(request);

            if (response.IsSuccessStatusCode)
            {
                var responseContent = await response.Content.ReadAsStringAsync();
                return Ok(responseContent);
            }
            else
            {
                var errorContent = await response.Content.ReadAsStringAsync();
                return BadRequest(new { status = response.StatusCode, error = errorContent });
            }
        }
    }
}
