﻿using Microsoft.AspNetCore.Mvc;
using System.Text.Json;
using System.Text;
using WebhookGail.Data;
using WebhookGail.Models;
using WebhookGail.Middleware;

namespace WebhookGail.Controllers
{
    [ApiController]
    [Route("axia/contact_lists")]
    [ServiceFilter(typeof(TokenValidationMiddleware))]
    public class APIContactListController : Controller
    {
        private readonly ILogger<APIContactListController> _logger;
        private readonly HttpClient _httpClient;
        private readonly WebhookGailContext _dbContext;
        private readonly IConfiguration _configuration;
        private readonly string? _apiKey;
        private readonly string? _endpoint;

        public APIContactListController(ILogger<APIContactListController> logger, HttpClient httpClient, WebhookGailContext dbcontext, IConfiguration configuration)
        {
            _logger = logger;
            _httpClient = httpClient;
            _dbContext = dbcontext;
            _configuration = configuration;
            _apiKey = configuration["GailAPI:ApiKey"];
            _endpoint = configuration["GailAPI:Endpoint"];
        }

        private void AddCommonHeaders(HttpRequestMessage request)
        {
            request.Headers.Add("Authorization", "Bearer YOUR_ACCESS_TOKEN");
            request.Headers.Add("X-Org-ID", "3fa85f64-5717-4562-b3fc-2c963f66afa6");
        }

        [HttpGet]
        public async Task<IActionResult> GetContactListsAsync()
        {
            var request = new HttpRequestMessage(HttpMethod.Get, $"{_endpoint}/v1/contact_lists");
            AddCommonHeaders(request);

            var response = await _httpClient.SendAsync(request);

            if (response.IsSuccessStatusCode)
            {
                var responseContent = await response.Content.ReadAsStringAsync();
                return Ok(responseContent);
            }
            else
            {
                var errorContent = await response.Content.ReadAsStringAsync();
                return BadRequest(new { status = response.StatusCode, error = errorContent });
            }
        }

        [HttpGet("{id}")]
        public async Task<IActionResult> GetContactListAsync([FromRoute] string id)
        {
            var request = new HttpRequestMessage(HttpMethod.Get, $"{_endpoint}/v1/contact_lists/{id}");
            AddCommonHeaders(request);

            var response = await _httpClient.SendAsync(request);

            if (response.IsSuccessStatusCode)
            {
                var responseContent = await response.Content.ReadAsStringAsync();
                return Ok(responseContent);
            }
            else
            {
                var errorContent = await response.Content.ReadAsStringAsync();
                return BadRequest(new { status = response.StatusCode, error = errorContent });
            }
        }

        [HttpPost]
        public async Task<IActionResult> CreateContactListAsync([FromBody] ContactList contactList)
        {
            try
            {
                var request = new HttpRequestMessage(HttpMethod.Post, $"{_endpoint}/v1/contact_lists");
                AddCommonHeaders(request);

                string jsonContent = JsonSerializer.Serialize(contactList);
                request.Content = new StringContent(jsonContent, Encoding.UTF8, "application/json");

                var response = await _httpClient.SendAsync(request);

                if (response.IsSuccessStatusCode)
                {
                    var responseContent = await response.Content.ReadAsStringAsync();
                    return Created("", responseContent);
                }
                else
                {
                    var errorContent = await response.Content.ReadAsStringAsync();
                    return BadRequest(new { status = response.StatusCode, error = errorContent });
                }
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Internal server error: {ex.Message}");
            }
        }

        [HttpPut("{id}")]
        public async Task<IActionResult> UpdateContactListAsync([FromRoute] string id, [FromBody] ContactList contactList)
        {
            try
            {
                var request = new HttpRequestMessage(HttpMethod.Put, $"{_endpoint}/v1/contact_lists/{id}");
                AddCommonHeaders(request);

                string jsonContent = JsonSerializer.Serialize(contactList);
                request.Content = new StringContent(jsonContent, Encoding.UTF8, "application/json");

                var response = await _httpClient.SendAsync(request);

                if (response.IsSuccessStatusCode)
                {
                    var responseContent = await response.Content.ReadAsStringAsync();
                    return Ok(responseContent);
                }
                else
                {
                    var errorContent = await response.Content.ReadAsStringAsync();
                    return BadRequest(new { status = response.StatusCode, error = errorContent });
                }
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Internal server error: {ex.Message}");
            }
        }

        [HttpPost("{id}/archive")]
        public async Task<IActionResult> ArchiveContactListAsync([FromRoute] string id)
        {
            try
            {
                var request = new HttpRequestMessage(HttpMethod.Post, $"{_endpoint}/v1/contact_lists/{id}/archive");
                AddCommonHeaders(request);

                var response = await _httpClient.SendAsync(request);

                if (response.IsSuccessStatusCode)
                {
                    var responseContent = await response.Content.ReadAsStringAsync();
                    return Ok(responseContent);
                }
                else
                {
                    var errorContent = await response.Content.ReadAsStringAsync();
                    return BadRequest(new { status = response.StatusCode, error = errorContent });
                }
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Internal server error: {ex.Message}");
            }
        }

        [HttpPost("{id}/restore")]
        public async Task<IActionResult> RestoreContactListAsync([FromRoute] string id)
        {
            try
            {
                var request = new HttpRequestMessage(HttpMethod.Post, $"{_endpoint}/v1/contact_lists/{id}/restore");
                AddCommonHeaders(request);

                var response = await _httpClient.SendAsync(request);

                if (response.IsSuccessStatusCode)
                {
                    var responseContent = await response.Content.ReadAsStringAsync();
                    return Ok(responseContent);
                }
                else
                {
                    var errorContent = await response.Content.ReadAsStringAsync();
                    return BadRequest(new { status = response.StatusCode, error = errorContent });
                }
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Internal server error: {ex.Message}");
            }
        }

        [HttpGet("{id}/contacts")]
        public async Task<IActionResult> GetContactsInListAsync([FromRoute] string id)
        {
            var request = new HttpRequestMessage(HttpMethod.Get, $"{_endpoint}/v1/contact_lists/{id}/contacts");
            AddCommonHeaders(request);

            var response = await _httpClient.SendAsync(request);

            if (response.IsSuccessStatusCode)
            {
                var responseContent = await response.Content.ReadAsStringAsync();
                return Ok(responseContent);
            }
            else
            {
                var errorContent = await response.Content.ReadAsStringAsync();
                return BadRequest(new { status = response.StatusCode, error = errorContent });
            }
        }

        [HttpPost("{id}/add")]
        public async Task<IActionResult> AddContactsToListAsync([FromRoute] string id, [FromBody] ContactListAddRequest requestBody)
        {
            try
            {
                var request = new HttpRequestMessage(HttpMethod.Post, $"{_endpoint}/v1/contact_lists/{id}/add");
                AddCommonHeaders(request);

                string jsonContent = JsonSerializer.Serialize(requestBody);
                request.Content = new StringContent(jsonContent, Encoding.UTF8, "application/json");

                var response = await _httpClient.SendAsync(request);

                if (response.IsSuccessStatusCode)
                {
                    return Accepted();
                }
                else
                {
                    var errorContent = await response.Content.ReadAsStringAsync();
                    return BadRequest(new { status = response.StatusCode, error = errorContent });
                }
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Internal server error: {ex.Message}");
            }
        }

        [HttpPost("{id}/remove")]
        public async Task<IActionResult> RemoveContactsFromListAsync([FromRoute] string id, [FromBody] ContactListAddRequest requestBody)
        {
            try
            {
                var request = new HttpRequestMessage(HttpMethod.Post, $"{_endpoint}/v1/contact_lists/{id}/remove");
                AddCommonHeaders(request);

                string jsonContent = JsonSerializer.Serialize(requestBody);
                request.Content = new StringContent(jsonContent, Encoding.UTF8, "application/json");

                var response = await _httpClient.SendAsync(request);

                if (response.IsSuccessStatusCode)
                {
                    return Accepted();
                }
                else
                {
                    var errorContent = await response.Content.ReadAsStringAsync();
                    return BadRequest(new { status = response.StatusCode, error = errorContent });
                }
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Internal server error: {ex.Message}");
            }
        }
    }
}
