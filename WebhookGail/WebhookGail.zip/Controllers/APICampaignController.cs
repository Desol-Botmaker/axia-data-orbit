﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Net.Http;
using System.Text.Json;
using System.Text;
using WebhookGail.Data;
using WebhookGail.Models;
using WebhookGail.Middleware;

namespace WebhookGail.Controllers
{
    [ApiController]
    [Route("axia/campaigns")]
    [ServiceFilter(typeof(TokenValidationMiddleware))]
    public class APICampaignController : ControllerBase
    {
        private readonly ILogger<APICampaignController> _logger;
        private readonly HttpClient _httpClient;
        private readonly WebhookGailContext _dbContext;
        private readonly IConfiguration _configuration;
        private readonly string? _apiKey;
        private readonly string? _endpoint;
        public APICampaignController(ILogger<APICampaignController> logger, HttpClient httpClient, WebhookGailContext dbcontext, IConfiguration configuration) {
        
            _logger = logger;
            _httpClient = httpClient;
            _dbContext = dbcontext;
            _configuration = configuration;
            _apiKey = configuration["GailAPI:ApiKey"];
            _endpoint = configuration["GailAPI:Endpoint"];
        }

        private void AddCommonHeaders(HttpRequestMessage request)
        {
            request.Headers.Add("Authorization", "Bearer YOUR_ACCESS_TOKEN");
            request.Headers.Add("X-Org-ID", "3fa85f64-5717-4562-b3fc-2c963f66afa6");
        }

        [HttpGet]
        public async Task<IActionResult> GetCampaignsAsync()
        {
            var request = new HttpRequestMessage(HttpMethod.Get, _endpoint + "/v1/campaigns");
            AddCommonHeaders(request);

            var response = await _httpClient.SendAsync(request);

            if (response.IsSuccessStatusCode)
            {
                return Ok(response);
            }
            else
            {
                return BadRequest(response);
            }
        }

        [HttpGet("{id}")]
        public async Task<IActionResult> GetCampaignAsync([FromQuery] int id)
        {
            var request = new HttpRequestMessage(HttpMethod.Get, _endpoint + "/v1/campaigns/" + id.ToString());
            AddCommonHeaders(request);

            var response = await _httpClient.SendAsync(request);

            if (response.IsSuccessStatusCode)
            {
                return Ok(response);
            }
            else
            {
                return BadRequest(response);
            }
        }

        [HttpPost]
        public async Task<IActionResult> PostCampaignAsync([FromBody] AxiaCampaign axiaCampaign)
        {
            try
            {
                var request = new HttpRequestMessage(HttpMethod.Post, _endpoint + "/v1/campaigns");
                AddCommonHeaders(request);

                string jsonContent = JsonSerializer.Serialize(axiaCampaign);
                request.Content = new StringContent(jsonContent, Encoding.UTF8, "application/json");

                var response = await _httpClient.SendAsync(request);

                if (response.IsSuccessStatusCode)
                {
                    var responseContent = await response.Content.ReadAsStringAsync();
                    return Ok(responseContent);
                }
                else
                {
                    var errorContent = await response.Content.ReadAsStringAsync();
                    return BadRequest(new { status = response.StatusCode, error = errorContent });
                }
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Internal server error: {ex.Message}");
            }
        }

        [HttpPut("{id}")]
        public async Task<IActionResult> UpdateCampaignAsync([FromBody] AxiaCampaign axiaCampaign, [FromRoute] string id)
        {
            try
            {
                var request = new HttpRequestMessage(HttpMethod.Put, $"{_endpoint}/v1/campaigns/{id}");
                AddCommonHeaders(request);

                string jsonContent = JsonSerializer.Serialize(axiaCampaign);
                request.Content = new StringContent(jsonContent, Encoding.UTF8, "application/json");

                var response = await _httpClient.SendAsync(request);

                if (response.IsSuccessStatusCode)
                {
                    var responseContent = await response.Content.ReadAsStringAsync();
                    return Ok(responseContent);
                }
                else
                {
                    var errorContent = await response.Content.ReadAsStringAsync();
                    return BadRequest(new { status = response.StatusCode, error = errorContent });
                }
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Internal server error: {ex.Message}");
            }
        }

        [HttpPost("{id}/start")]
        public async Task<IActionResult> StartCampaignAsync([FromRoute] string id)
        {
            return await ExecutePostRequest($"{_endpoint}/v1/campaigns/{id}/start");
        }

        [HttpPost("{id}/stop")]
        public async Task<IActionResult> StopCampaignAsync([FromRoute] string id)
        {
            return await ExecutePostRequest($"{_endpoint}/v1/campaigns/{id}/stop");
        }

        [HttpPost("{id}/archive")]
        public async Task<IActionResult> ArchiveCampaignAsync([FromRoute] string id)
        {
            return await ExecutePostRequest($"{_endpoint}/v1/campaigns/{id}/archive");
        }

        [HttpPost("{id}/restore")]
        public async Task<IActionResult> RestoreCampaignAsync([FromRoute] string id)
        {
            return await ExecutePostRequest($"{_endpoint}/v1/campaigns/{id}/restore");
        }

        [HttpPost("{id}/contacts")]
        public async Task<IActionResult> AddContactAsync([FromRoute] string id, [FromBody] Contact contact)
        {
            try
            {
                var request = new HttpRequestMessage(HttpMethod.Post, $"{_endpoint}/v1/campaigns/{id}/contacts");
                AddCommonHeaders(request);

                string jsonContent = JsonSerializer.Serialize(contact);
                request.Content = new StringContent(jsonContent, Encoding.UTF8, "application/json");

                var response = await _httpClient.SendAsync(request);

                if (response.IsSuccessStatusCode)
                {
                    return Accepted();
                }
                else
                {
                    var errorContent = await response.Content.ReadAsStringAsync();
                    return BadRequest(new { status = response.StatusCode, error = errorContent });
                }
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Internal server error: {ex.Message}");
            }
        }

        [HttpPost("{id}/contacts/bulk_add")]
        public async Task<IActionResult> BulkAddContactsAsync([FromRoute] string id, [FromBody] List<Contact> contacts)
        {
            try
            {
                var request = new HttpRequestMessage(HttpMethod.Post, $"{_endpoint}/v1/campaigns/{id}/contacts/bulk_add");
                AddCommonHeaders(request);

                string jsonContent = JsonSerializer.Serialize(contacts);
                request.Content = new StringContent(jsonContent, Encoding.UTF8, "application/json");

                var response = await _httpClient.SendAsync(request);

                if (response.IsSuccessStatusCode)
                {
                    return StatusCode(207, "Success");
                }
                else
                {
                    var errorContent = await response.Content.ReadAsStringAsync();
                    return BadRequest(new { status = response.StatusCode, error = errorContent });
                }
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Internal server error: {ex.Message}");
            }
        }

        [HttpGet("{id}/touchpoints")]
        public async Task<IActionResult> GetCampaignTouchpointsAsync([FromRoute] string id)
        {
            try
            {
                var request = new HttpRequestMessage(HttpMethod.Get, $"{_endpoint}/v1/campaigns/{id}/touchpoints");
                AddCommonHeaders(request);

                var response = await _httpClient.SendAsync(request);

                if (response.IsSuccessStatusCode)
                {
                    var responseContent = await response.Content.ReadAsStringAsync();
                    return Ok(responseContent);
                }
                else
                {
                    var errorContent = await response.Content.ReadAsStringAsync();
                    return BadRequest(new { status = response.StatusCode, error = errorContent });
                }
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Internal server error: {ex.Message}");
            }
        }

        private async Task<IActionResult> ExecutePostRequest(string url)
        {
            try
            {
                var request = new HttpRequestMessage(HttpMethod.Post, url);
                AddCommonHeaders(request);

                var response = await _httpClient.SendAsync(request);

                if (response.IsSuccessStatusCode)
                {
                    var responseContent = await response.Content.ReadAsStringAsync();
                    return Ok(responseContent);
                }
                else
                {
                    var errorContent = await response.Content.ReadAsStringAsync();
                    return BadRequest(new { status = response.StatusCode, error = errorContent });
                }
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Internal server error: {ex.Message}");
            }
        }

    }
}
