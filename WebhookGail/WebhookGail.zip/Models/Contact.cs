﻿namespace WebhookGail.Models
{
    public class Contact
    {
        public string? Id { get; set; }
        public string? Status { get; set; }
        public string? FirstName { get; set; }
        public string? LastName { get; set; }
        public List<string>? Emails { get; set; }
        public List<PhoneNumber>? PhoneNumbers { get; set; }
        public string? BusinessName { get; set; }
        public string? Source { get; set; }
        public Dictionary<string, string>? AdditionalData { get; set; }
    }

    public class PhoneNumber
    {
        public string? Number { get; set; }
        public string? Type { get; set; } // "home", "mobile", "work"
    }
}
