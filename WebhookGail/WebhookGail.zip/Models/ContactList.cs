﻿namespace WebhookGail.Models
{
    public class ContactList
    {
        public string Name { get; set; }
        public string Description { get; set; }
    }

    public class ContactListAddRequest
    {
        public List<string> ContactIds { get; set; }
    }
}
