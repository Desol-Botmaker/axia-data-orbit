﻿using System.Text.Json.Serialization;

namespace WebhookGail.Models
{
    public class SurveyResponseResult
    {
        [JsonPropertyName("survey_id")]
        public int SurveyId { get; set; }

        [JsonPropertyName("updated")]
        public DateTime Updated { get; set; }

        [JsonPropertyName("answers")]
        public List<AnswerResult> Answers { get; set; }
    }

    public class AnswerResult
    {
        [JsonPropertyName("question")]
        public int Question { get; set; }

        [JsonPropertyName("question_text")]
        public string? QuestionText { get; set; }

        [JsonPropertyName("body")]
        public string? Body { get; set; }
    }
}
