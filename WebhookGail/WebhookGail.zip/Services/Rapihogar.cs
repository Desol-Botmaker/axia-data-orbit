﻿using Microsoft.Extensions.Logging;
using System.Net.Http.Headers;
using System.Net.Http;
using System.Text;
using System.Text.Json;
using WebhookGail.Models;

namespace WebhookGail.Services
{
    public class Rapihogar
    {
        private readonly IConfiguration _configuration;
        private readonly ILogger<Rapihogar> _logger; 
        private readonly HttpClient _httpClient;

        public Rapihogar(IConfiguration configuration, ILogger<Rapihogar> logger, HttpClient httpClient)
        {
            _configuration = configuration;
            _logger = logger;
            _httpClient = httpClient;
        }

        private string _currentAccessToken;
        private DateTime _tokenExpirationTime;

        public async Task<string> GetAccessTokenAsync()
        {
            _logger.LogDebug("Token expiration time: " + _tokenExpirationTime);

            if (!string.IsNullOrEmpty(_currentAccessToken) && DateTime.UtcNow < _tokenExpirationTime)
            {
                _logger.LogDebug("Reutilizando el token existente.");
                return _currentAccessToken;
            }

            string? uri = _configuration["AppSettings:RapihogarAPI"] + "oauth/token";
            var client = new HttpClient();
            var request = new HttpRequestMessage(HttpMethod.Post, "https://backend.rapihogar.com.ar/oauth/token/");
            var collection = new List<KeyValuePair<string, string>>();

            collection.Add(new("grant_type", "client_credentials"));
            collection.Add(new("client_id", _configuration["AppSettings:RapihogarClientId"] ?? ""));
            collection.Add(new("client_secret", _configuration["AppSettings:RapihogarClientSecret"] ?? ""));

            var content = new FormUrlEncodedContent(collection);

            request.Content = content;

            var response = await client.SendAsync(request);
            response.EnsureSuccessStatusCode();

            string contentString = await response.Content.ReadAsStringAsync();
            var jsonDocument = JsonDocument.Parse(contentString);
            RapiToken? accessTokenResponse = JsonSerializer.Deserialize<RapiToken>(jsonDocument);

            _currentAccessToken = accessTokenResponse.access_token;

            _logger.LogDebug(DateTime.UtcNow.ToString());

            _tokenExpirationTime = DateTime.UtcNow.AddSeconds(36000);

            _logger.LogDebug("Nuevo token obtenido");
            _logger.LogDebug("Token expira en: " + _tokenExpirationTime.ToString());
            return _currentAccessToken;
        }


        public async Task<SurveyResponseResult> SendSurveyResponseAsync(JsonElement surveyResponse)
        {
            _logger.LogInformation("Enviando respuestas de encuesta.");

            string? baseUrl = _configuration["AppSettings:RapihogarAPI"];
            string? version = _configuration["AppSettings:RapihogarAPIVersion"];
            string endpoint = $"{baseUrl}/{version}/axia/survey/";

            string bearerToken = await GetAccessTokenAsync();

            var request = new HttpRequestMessage(HttpMethod.Post, endpoint);
            request.Headers.Authorization = new AuthenticationHeaderValue("Bearer", bearerToken);
            request.Content = new StringContent(JsonSerializer.Serialize(surveyResponse), Encoding.UTF8, "application/json");

            try
            {
                var response = await _httpClient.SendAsync(request);
                response.EnsureSuccessStatusCode();

                string contentString = await response.Content.ReadAsStringAsync();
                var surveyResponseResult = JsonSerializer.Deserialize<SurveyResponseResult>(contentString, new JsonSerializerOptions
                {
                    PropertyNameCaseInsensitive = true
                });

                _logger.LogInformation("Respuestas de encuesta enviadas correctamente.");
                return surveyResponseResult;
            }
            catch (HttpRequestException ex)
            {
                _logger.LogError(ex, "Error al enviar las respuestas de la encuesta.");
                throw;
            }
        }


    }
}
