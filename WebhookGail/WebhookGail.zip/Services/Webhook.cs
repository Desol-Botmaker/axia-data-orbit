﻿using Microsoft.EntityFrameworkCore;
using System.Text.Encodings.Web;
using System.Text.Json;
using System.Text.Unicode;
using WebhookGail.Data;
using WebhookGail.Models;

namespace WebhookGail.Services
{
    public class WebhookService
    {
        private readonly WebhookGailContext _dbContext;
        private readonly OpenAIService _openAI;
        private readonly IConfiguration _configuration;
        private readonly ILogger<WebhookService> _logger;

        public WebhookService(WebhookGailContext dbContext, OpenAIService openAI, IConfiguration configuration, ILogger<WebhookService> logger)
        {
            _dbContext = dbContext;
            _openAI = openAI;
            _configuration = configuration;
            _logger = logger;
        }

        public async Task<LogWebhookGail> ProcessPayloadAsync(Payload payloadObject, string businessName)
        {
            bool voicemail = payloadObject.call_information?.voicemail == "true";
            string structuredData = string.Empty;

            Instructions? instructions = await _dbContext.Instructions.FirstOrDefaultAsync(i => i.Business == businessName
                                            && EF.Functions.Like(payloadObject.call_information.script_name, "%" + i.ScriptId + "%"));

            if (instructions != null)
            {
                if (instructions.Variable == "questions")
                {
                    string questions = JsonSerializer.Serialize(payloadObject.call_information?.questions ?? new List<Question>(), new JsonSerializerOptions
                    {
                        Encoder = JavaScriptEncoder.Create(UnicodeRanges.All),
                        WriteIndented = false
                    });

                    structuredData = await _openAI.ProcessTranscriptionAsync(questions, instructions.Instruction);
                    _logger.LogDebug("Usando OpenAI para modelar los datos de questions");
                }
                else if (instructions.Variable == "summary")
                {
                    string summary = JsonSerializer.Serialize(payloadObject.call_information.summary);
                    _logger.LogDebug("Sumario: " + summary);
                    structuredData = await _openAI.ProcessTranscriptionAsync(summary, instructions.Instruction);
                    _logger.LogDebug("Usando OpenAI para modelar los datos de summary");
                }
            }

            string translatedSummary = await _openAI.TranslateToSpanishAsync(payloadObject.call_information?.summary);

            int hourOffset = _configuration.GetValue<int>("TimeSettings:HourOffset");
            DateTime utcNow = DateTime.UtcNow;
            DateTime adjustedTime = utcNow.AddHours(hourOffset);

            var logEntry = new LogWebhookGail
            {
                IdGail = Guid.Parse(payloadObject.id),
                Sid = payloadObject.sid,
                Date = adjustedTime,
                ScriptId = payloadObject.call_information?.script_id,
                ScriptName = payloadObject.call_information?.script_name,
                Direction = payloadObject.direction,
                Duration = payloadObject.duration,
                FromNumber = payloadObject.from_number,
                ToNumber = payloadObject.to_number,
                Status = payloadObject.status,
                CustomerName = payloadObject.call_information?.name,
                StatedPhoneNumber = payloadObject.call_information?.stated_phone_number,
                Interested = payloadObject.call_information?.interested,
                Questions = JsonSerializer.Serialize(payloadObject.call_information?.questions ?? new List<Question>(), new JsonSerializerOptions
                {
                    Encoder = JavaScriptEncoder.Create(UnicodeRanges.All),
                    WriteIndented = false
                }),
                Note = payloadObject.call_information?.note,
                Email = payloadObject.call_information?.email,
                Summary = translatedSummary,
                DataCollected = structuredData ?? JsonSerializer.Serialize(payloadObject.call_information?.data_collected ?? new Dictionary<string, object>(), new JsonSerializerOptions
                {
                    Encoder = JavaScriptEncoder.Create(UnicodeRanges.All),
                    WriteIndented = false
                }),
                CategoryOfCall = payloadObject.call_information?.category_of_call,
                ReasonOfCall = payloadObject.call_information?.reason_of_call,
                CallBackRequested = payloadObject.call_information?.call_back_requested,
                CallBackTime = payloadObject.call_information?.call_back_time,
                Resolution = payloadObject.call_information?.resolution,
                Information = payloadObject.call_information?.information,
                Business = payloadObject.call_information?.business,
                VoiceMail = voicemail,
                CallerSatisfactionRating = payloadObject.call_information?.caller_satisfaction_rating ?? 0,
                CallDisconnectReason = payloadObject.call_information?.call_disconnect_reason,
                OrgSatisfactionRating = payloadObject.call_information?.org_satisfaction_rating ?? 0,
                Flagged = payloadObject.call_information?.flagged ?? false,
                Reviewed = payloadObject.call_information?.reviewed ?? false,
                ExtendedInformation = JsonSerializer.Serialize(payloadObject.call_information?.extended_information ?? new Dictionary<string, object>(), new JsonSerializerOptions
                {
                    Encoder = JavaScriptEncoder.Create(UnicodeRanges.All),
                    WriteIndented = false
                }),
                QuestionsText = payloadObject.call_information?.questions_text,
                DataCollectedText = payloadObject.call_information?.data_collected_text,
                CallInformationJson = payloadObject.call_information_json,
                RecordingUrl = payloadObject.recording_url,
                CallBackStartTime = payloadObject.callback_start_time,
                Notes = JsonSerializer.Serialize(payloadObject.notes ?? new List<Note>(), new JsonSerializerOptions
                {
                    Encoder = JavaScriptEncoder.Create(UnicodeRanges.All),
                    WriteIndented = false
                }),
                BusinessName = businessName
            };

            return logEntry;
        }
    }
}
