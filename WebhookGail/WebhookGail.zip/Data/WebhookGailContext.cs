﻿using Microsoft.EntityFrameworkCore;
using WebhookGail.Models;

namespace WebhookGail.Data
{
    public class WebhookGailContext : DbContext
    {
        public WebhookGailContext(DbContextOptions<WebhookGailContext> options) : base(options)
        {
        }
        public DbSet<Instructions> Instructions { get; set; }
        public DbSet<LogWebhookGail> LogWebhookGail { get; set; }

        public DbSet<LogWebhookGailView> LogWebhookGailView { get; set; }
        public DbSet<Customer> Customer { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<LogWebhookGail>().ToTable("LOG_WEBHOOK_AXIA");
            modelBuilder.Entity<LogWebhookGailView>()
                .ToView("LIST_CALLS_AXIA") 
                .HasNoKey();
            modelBuilder.Entity<Customer>().ToTable("CUSTOMERS_AXIA");
            modelBuilder.Entity<Instructions>().ToTable("OPENAI_INSTRUCTIONS_AXIA");
        }
    }

}
